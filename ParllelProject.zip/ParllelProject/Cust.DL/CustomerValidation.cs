﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Entity;
using Cust.Exception;

namespace Cust.BL
{
    public class CustomerValidation
    {
        public static bool ValidateCustomer(Customer customer)
        {
            bool customerValidated = true;
            StringBuilder errMessage = new StringBuilder();
            try
            {
                if(customer.CustomerID < 100000 || customer.CustomerID > 999999)
                {
                    customerValidated = false;
                    errMessage.Append("Customer ID should be 6 digits long\n");
                }
                if (string.IsNullOrEmpty(customer.CustomerName))
                {
                    customerValidated = false;
                    errMessage.Append("Customer Name should be provided\n");
                }
                else if (!Regex.IsMatch(customer.CustomerName, "[A-Z][a-z]+"))
                {
                    customerValidated = false;
                    errMessage.Append("Customer Name should start with capital alphabet and it should have alphabets only\n");
                }
                if (string.IsNullOrEmpty(customer.City))
                {
                    customerValidated = false;
                    errMessage.Append("City should be provided\n");
                }
                if (customer.Age < 0)
                {
                    customerValidated = false;
                    errMessage.Append("Age should not be negative\n");
                }
                if (string.IsNullOrEmpty(customer.Phone))
                {
                    customerValidated = false;
                    errMessage.Append("Phone should be provided\n");
                }
                else if (!Regex.Equals(customer.Phone, "[0-9]{10}"))
                    if (customerValidated == false)
                    {
                        throw new CustomerExecption(errMessage.ToString());
                    }
                if (customer.Pincode < 0)
                {
                    customerValidated = false;
                    errMessage.Append("Pincode should not be negative\n");
                }
            }
            catch (CustomerExecption ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerValidated;
        }
        public static bool AddCustomer(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                if(ValidateCustomer(newCustomer))
                {

                }
            }
            catch (System.Exception)
            {

                throw;
            }

            return customerAdded;

        }
            
     }
}

