﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cust.Exception
{
    public class CustomerExecption: ApplicationException
    {
        public CustomerExecption():base()
        {
        }
        public CustomerExecption(string message):base(message)
        {
        }
    }
}
