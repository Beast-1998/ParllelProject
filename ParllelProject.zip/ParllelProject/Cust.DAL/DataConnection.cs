﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cust.DAL
{
    class DataConnection
    {
        public static DbCommand CreateCommand()
        {
            string dataProviderName = CustomerConfiguration.ProviderName;
            string connectionString = CustomerConfiguration.ConnectionString;

            DbProviderFactory factory = DbProviderFactories.GetFactory(dataProviderName);
            DbConnection connection = factory.CreateConnection();
            connection.ConnectionString = connectionString;
            DbCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            return command;
        }
    }
}
