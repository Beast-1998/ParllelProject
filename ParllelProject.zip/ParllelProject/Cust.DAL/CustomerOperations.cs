﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace Cust.DAL
{
    class CustomerOperations
    {
        public bool AddCustomerDAL(Customer customer)
        {
            bool customerAdded = false;
            try
            {
                DbCommand command=DataConnection
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
